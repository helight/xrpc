#ifdef __NETWARE__
#undef printf
#undef puts
#undef fputs
#undef putchar
#endif
